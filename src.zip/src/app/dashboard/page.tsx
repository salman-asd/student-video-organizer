"use client";

import * as React from "react";
import Link from "next/link";
import { AppShell } from "@/components/layout/AppShell";
import { RequireAuth } from "@/components/auth/RequireAuth";
import { useAuth } from "@/components/auth/AuthProvider";
import { useVideoLibrary } from "@/hooks/useVideoLibrary";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { listPersonalPlaylists } from "@/lib/firestore/personalPlaylists";
import { isResumeEligible } from "@/lib/watchProgress";
import { VideoCard } from "@/components/video/VideoCard";
import type { PersonalPlaylist, VideoWithState } from "@/types";
import { Clock3, FolderPlus, ListVideo, Plus, Star, Flag, Download, BookOpen } from "lucide-react";

export default function DashboardPage() {
  return (
    <RequireAuth>
      <DashboardContent />
    </RequireAuth>
  );
}

function DashboardContent() {
  const { user, profile } = useAuth();
  const { loading, videos } = useVideoLibrary(user?.uid);
  const [playlists, setPlaylists] = React.useState<PersonalPlaylist[]>([]);

  React.useEffect(() => {
    if (!user?.uid) return;
    listPersonalPlaylists(user.uid).then(setPlaylists).catch(() => setPlaylists([]));
  }, [user?.uid]);

  const continueWatching = React.useMemo(() => {
    return videos.filter((video) => !!video.state && isResumeEligible(video.state)).sort((a, b) => {
      const bLast = b.state?.lastWatchedAt ? tsMillis(b.state.lastWatchedAt) : 0;
      const aLast = a.state?.lastWatchedAt ? tsMillis(a.state.lastWatchedAt) : 0;
      return bLast - aLast || (b.state?.watchedPercentage || 0) - (a.state?.watchedPercentage || 0);
    }).slice(0, 4);
  }, [videos]);

  const watchLater = React.useMemo(() => videos.filter((video) => video.state?.isWatchLater).slice(0, 4), [videos]);
  const highPriority = React.useMemo(() => videos.filter((video) => video.state?.priority === "high").slice(0, 4), [videos]);
  const favorites = React.useMemo(() => videos.filter((video) => video.state?.isFavorite).slice(0, 4), [videos]);
  const recentlyAdded = React.useMemo(() => [...videos].sort((a, b) => tsMillis(b.createdAt) - tsMillis(a.createdAt)).slice(0, 4), [videos]);

  return (
    <AppShell>
      <div className="mx-auto max-w-7xl space-y-6">
        <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="text-sm text-muted-foreground">{greeting()}, {profile?.displayName?.split(" ")[0] || "there"}</p>
            <h1 className="font-display text-2xl font-semibold">What are you learning today?</h1>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button asChild size="sm"><Link href="/library"><Plus className="h-4 w-4" /> Add Video</Link></Button>
            <Button asChild variant="outline" size="sm"><Link href="/my-playlists"><FolderPlus className="h-4 w-4" /> Create Playlist</Link></Button>
            <Button asChild variant="outline" size="sm"><Link href="/admin/import-youtube"><Download className="h-4 w-4" /> Import Playlist</Link></Button>
          </div>
        </div>

        <DashboardSection title="Continue Watching" viewAllHref="/continue-learning" loading={loading} emptyText="Nothing in progress yet. Pick up a video from your library to continue learning." items={continueWatching} renderItem={(video) => <VideoCard key={video.id} video={video} showActions={false} />} />
        <DashboardSection title="Watch Later" viewAllHref="/watch-later" loading={loading} emptyText="Nothing saved for later. Tap Watch Later on any video to keep it queued." items={watchLater} renderItem={(video) => <VideoCard key={video.id} video={video} showActions={false} />} />
        <DashboardSection title="High Priority" viewAllHref="/priority" loading={loading} emptyText="No high-priority videos yet. Mark a video as high priority when it needs attention." items={highPriority} renderItem={(video) => <VideoCard key={video.id} video={video} showActions={false} />} />
        <DashboardSection title="Favorites" viewAllHref="/favorites" loading={loading} emptyText="No favorites yet. Save videos you want to revisit later." items={favorites} renderItem={(video) => <VideoCard key={video.id} video={video} showActions={false} />} />
        <DashboardSection title="Recently Added" loading={loading} emptyText="No recent videos yet. Add or import content to get started." items={recentlyAdded} renderItem={(video) => <VideoCard key={video.id} video={video} showActions={false} />} />

        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-semibold">My Playlists</h2>
            <Link href="/my-playlists" className="text-sm text-muted-foreground hover:text-foreground">View all</Link>
          </div>
          {loading ? (
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
              {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-32 w-full rounded-lg" />)}
            </div>
          ) : playlists.length === 0 ? (
            <div className="rounded-lg border border-dashed p-8 text-center text-sm text-muted-foreground">
              You have no personal playlists yet. Create one to group videos by topic or course.
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
              {playlists.slice(0, 4).map((playlist) => (
                <Link key={playlist.id} href={`/my-playlists/${playlist.id}`}>
                  <Card className="h-full transition-shadow hover:shadow-md">
                    <CardContent className="space-y-3 p-4">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <ListVideo className="h-4 w-4" />
                        <span className="text-xs uppercase tracking-wide">Playlist</span>
                      </div>
                      <div className="space-y-1">
                        <h3 className="line-clamp-2 text-base font-medium">{playlist.title}</h3>
                        {playlist.description && <p className="line-clamp-2 text-sm text-muted-foreground">{playlist.description}</p>}
                      </div>
                      <div className="flex items-center justify-between text-sm text-muted-foreground">
                        <span>{playlist.videoCount} videos</span>
                        <BookOpen className="h-4 w-4" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </section>
      </div>
    </AppShell>
  );
}

function DashboardSection({
  title,
  viewAllHref,
  loading,
  emptyText,
  items,
  renderItem,
}: {
  title: string;
  viewAllHref?: string;
  loading: boolean;
  emptyText: string;
  items: VideoWithState[];
  renderItem: (video: VideoWithState) => React.ReactNode;
}) {
  return (
    <section className="space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-lg font-semibold">{title}</h2>
        {viewAllHref && (
          <Link href={viewAllHref} className="text-sm text-muted-foreground hover:text-foreground">View all</Link>
        )}
      </div>

      {loading ? (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-72 w-full rounded-lg" />)}
        </div>
      ) : items.length === 0 ? (
        <div className="rounded-lg border border-dashed p-8 text-center text-sm text-muted-foreground">{emptyText}</div>
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
          {items.map(renderItem)}
        </div>
      )}
    </section>
  );
}

function greeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}

function tsMillis(value: any): number {
  if (!value) return 0;
  if (typeof value.toMillis === "function") return value.toMillis();
  if (typeof value.toDate === "function") return value.toDate().getTime();
  return 0;
}
