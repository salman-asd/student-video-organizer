"use client";

import * as React from "react";
import { AppShell } from "@/components/layout/AppShell";
import { RequireAuth } from "@/components/auth/RequireAuth";
import { useAuth } from "@/components/auth/AuthProvider";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { listCategories } from "@/lib/firestore/categoriesTags";
import { getRoadmapTemplate, listLearningRoadmaps, updateLearningRoadmap } from "@/lib/firestore/roadmaps";
import { normalizeUserInterests } from "@/lib/userInterests";
import { doc, getDoc, updateDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import type { Category, LearningRoadmap, RoadmapLevel, RoadmapTemplate, UserInterest } from "@/types";
import { Check, Sparkles, PencilLine } from "lucide-react";
import { toast } from "sonner";

export default function RoadmapPage() {
  return (
    <RequireAuth>
      <RoadmapContent />
    </RequireAuth>
  );
}

function RoadmapContent() {
  const { user } = useAuth();
  const [categories, setCategories] = React.useState<Category[]>([]);
  const [interests, setInterests] = React.useState<UserInterest[]>([]);
  const [templates, setTemplates] = React.useState<Record<string, RoadmapTemplate[]>>({});
  const [personalRoadmaps, setPersonalRoadmaps] = React.useState<Record<string, LearningRoadmap[]>>({});
  const [loading, setLoading] = React.useState(true);

  const load = React.useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const [nextCategories, profileSnap, nextRoadmaps] = await Promise.all([
        listCategories(user.uid),
        getDoc(doc(db, "users", user.uid)),
        listLearningRoadmaps(user.uid),
      ]);
      const profileInterests = normalizeUserInterests(((profileSnap.data() as any)?.interests ?? []) as UserInterest[]);
      setCategories(nextCategories);
      setInterests(profileInterests);
      const nextTemplates: Record<string, RoadmapTemplate[]> = {};
      for (const category of nextCategories) {
        const entries = await Promise.all([
          getRoadmapTemplate(category.id, "basic"),
          getRoadmapTemplate(category.id, "intermediate"),
          getRoadmapTemplate(category.id, "advanced"),
        ]).then((items) => items.filter((item): item is RoadmapTemplate => !!item));
        nextTemplates[category.id] = entries;
      }
      setTemplates(nextTemplates);
      const byCategory: Record<string, LearningRoadmap[]> = {};
      for (const roadmap of nextRoadmaps) {
        byCategory[roadmap.categoryId] = [...(byCategory[roadmap.categoryId] || []), roadmap];
      }
      setPersonalRoadmaps(byCategory);
    } catch (error: any) {
      toast.error(error?.message || "Failed to load your roadmap data.");
    } finally {
      setLoading(false);
    }
  }, [user]);

  React.useEffect(() => { load(); }, [load]);

  async function generateTemplate(categoryId: string) {
    if (!user) return;
    const category = categories.find((item) => item.id === categoryId);
    try {
      const response = await fetch("/api/ai/roadmap/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ categoryId, categoryName: category?.name || "Learning topic" }),
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(payload?.error || "Unable to generate this roadmap.");
      await load();
      toast.success("Roadmap template generated.");
    } catch (error: any) {
      toast.error(error?.message || "Unable to generate the roadmap.");
    }
  }

  async function activateLevel(categoryId: string, level: RoadmapLevel) {
    if (!user) return;
    try {
      const res = await fetch("/api/roadmaps/adopt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ categoryId, level }),
      });
      const payload = await res.json().catch(() => ({}));
      if (!res.ok) {
        if (res.status === 404) {
          await generateTemplate(categoryId);
          return;
        }
        throw new Error(payload?.error || "Unable to adopt this roadmap.");
      }
      const profileSnap = await getDoc(doc(db, "users", user.uid));
      const existing = normalizeUserInterests(((profileSnap.data() as any)?.interests ?? []) as UserInterest[]);
      const next = normalizeUserInterests(existing.map((item) => ({
        categoryId: item.categoryId,
        level: item.categoryId === categoryId ? level : item.level,
      })));
      await updateDoc(doc(db, "users", user.uid), { interests: next });
      await load();
      toast.success(`You’re now learning ${level}.`);
    } catch (error: any) {
      toast.error(error?.message || "Unable to save your roadmap choice.");
    }
  }

  const interestCards = categories.filter((category) => interests.some((interest) => interest.categoryId === category.id));

  return (
    <AppShell>
      <div className="mx-auto max-w-5xl space-y-6 py-8">
        <div className="space-y-2">
          <p className="text-sm font-medium uppercase tracking-[0.2em] text-accent">Roadmap</p>
          <h1 className="font-display text-3xl font-semibold">Your learning path</h1>
          <p className="text-muted-foreground">Choose a level for each interest and keep a personal copy of the roadmap you’re following.</p>
        </div>

        {loading && <p className="text-sm text-muted-foreground">Loading roadmap data…</p>}

        {!loading && interestCards.length === 0 && (
          <Card>
            <CardContent className="p-6 text-sm text-muted-foreground">Add some interests in Settings or onboarding before creating roadmaps.</CardContent>
          </Card>
        )}

        <div className="space-y-4">
          {interestCards.map((category) => {
            const matchedInterest = interests.find((interest) => interest.categoryId === category.id);
            const level = matchedInterest?.level ?? "basic";
            const levelTemplates = templates[category.id] ?? [];
            const personal = personalRoadmaps[category.id] ?? [];
            const activeRoadmap = personal.find((item) => item.level === level) || personal[0];

            return (
              <Card key={category.id}>
                <CardContent className="space-y-4 p-5">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <h2 className="font-display text-xl font-semibold">{category.name}</h2>
                      <p className="text-sm text-muted-foreground">Current level: {level}</p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {(["basic", "intermediate", "advanced"] as RoadmapLevel[]).map((nextLevel) => (
                        <Button
                          key={nextLevel}
                          size="sm"
                          variant={nextLevel === level ? "default" : "outline"}
                          onClick={() => void activateLevel(category.id, nextLevel)}
                        >
                          {nextLevel === level && <Check className="mr-1 h-3.5 w-3.5" />} {nextLevel}
                        </Button>
                      ))}
                    </div>
                  </div>

                  {levelTemplates.length > 0 ? (
                    <div className="space-y-3">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground"><Sparkles className="h-4 w-4 text-accent" /> Suggested roadmap</div>
                      {levelTemplates.map((template) => (
                        <div key={template.id} className="rounded-md border border-border p-3">
                          <div className="mb-2 flex items-center justify-between gap-2">
                            <Badge variant="secondary">{template.level}</Badge>
                            {template.steps.length > 0 ? <span className="text-xs text-muted-foreground">{template.steps.length} steps</span> : null}
                          </div>
                          <ol className="space-y-2">
                            {template.steps.slice(0, 4).map((step, index) => (
                              <li key={`${template.id}-${index}`} className="flex gap-2 text-sm">
                                <span className="mt-0.5 inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-accent/10 text-[10px] font-semibold text-accent">
                                  {index + 1}
                                </span>
                                <div>
                                  <div className="font-medium">{step.title}</div>
                                  {step.description && <p className="text-muted-foreground">{step.description}</p>}
                                </div>
                              </li>
                            ))}
                          </ol>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex items-center justify-between gap-3 rounded-md border border-dashed border-border p-4">
                      <span className="text-sm text-muted-foreground">No roadmap template yet for this interest.</span>
                      <Button size="sm" onClick={() => void generateTemplate(category.id)}>Generate</Button>
                    </div>
                  )}

                  {activeRoadmap && (
                    <div className="space-y-2 rounded-md border border-border bg-muted/30 p-3">
                      <div className="flex items-center gap-2 text-sm font-medium"><PencilLine className="h-4 w-4 text-accent" /> Personal roadmap</div>
                      {activeRoadmap.steps.map((step, index) => (
                        <div key={`${activeRoadmap.id}-${index}`} className="rounded-md bg-background p-2">
                          <div className="flex gap-2 text-sm">
                            <span className="mt-0.5 inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-[10px] font-semibold text-primary">{index + 1}</span>
                            <div>
                              <div className="font-medium">{step.title}</div>
                              {step.description && <p className="text-muted-foreground">{step.description}</p>}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </AppShell>
  );
}
