"use client";

import * as React from "react";
import YouTube, { type YouTubeProps, type YouTubePlayer } from "react-youtube";
import { detectVideoPlatform, generateCanonicalUrl, generateEmbedUrl } from "@/lib/video-platforms";
import { FacebookEmbed } from "./FacebookEmbed";

interface Props {
  youtubeVideoId?: string | null;
  videoUrl: string;
  startSeconds?: number;
  autoPlay?: boolean;
  className?: string;
  onProgress: (currentSeconds: number, durationSeconds: number, force?: boolean) => void;
  onPause: (currentSeconds: number, durationSeconds: number, force?: boolean) => void;
  onEnded: (currentSeconds: number, durationSeconds: number) => void;
}

/**
 * Renders the YouTube IFrame player when a youtubeVideoId is available —
 * that path is unchanged and is the only one with progress tracking, since
 * it's the only platform whose iframe exposes a JS API to read/seek
 * playback position (react-youtube's onStateChange/getCurrentTime).
 *
 * Facebook videos and Reels render via FacebookEmbed (the SDK-based
 * `fb-video` xfbml player) instead of a bare iframe — see that
 * component's doc comment for why a plain `plugins/video.php` iframe
 * isn't used here despite `generateEmbedUrl` still being able to build
 * one. Vimeo (and anything else with a public direct-iframe embed) still
 * renders via generateEmbedUrl's iframe URL directly.
 *
 * There's no postMessage progress API for Facebook or Vimeo the way
 * there is for YouTube, so watch position isn't tracked for either — the
 * same trade-off YouTube's Shorts and every other non-YouTube platform
 * already made before this.
 *
 * Only when a platform has no public embed mechanism at all (a bare
 * `generic` URL) does this fall back to a simple "open externally" card —
 * this app never hosts or proxies video files itself.
 */
export function VideoPlayer({ youtubeVideoId, videoUrl, startSeconds = 0, autoPlay = false, className, onProgress, onPause, onEnded }: Props) {
  const playerRef = React.useRef<YouTubePlayer | null>(null);
  const intervalRef = React.useRef<ReturnType<typeof setInterval>>();
  // The YouTube IFrame API's own internal messaging can throw (its minified
  // code references an internal "M_ID" field) if a player method is called
  // while the player is mid-teardown or mid-video-swap — e.g. an in-flight
  // setInterval tick landing right as the component unmounts, or right as
  // Next/Prev swaps videos. This flag, plus a try/catch around every call
  // into the player, turns that into "skip this one save" instead of an
  // uncaught console error.
  const isMountedRef = React.useRef(true);

  const clearPoll = () => intervalRef.current && clearInterval(intervalRef.current);

  async function safeReadTime(target: YouTubePlayer): Promise<[number, number] | null> {
    if (!isMountedRef.current) return null;
    try {
      const [cur, dur] = await Promise.all([target.getCurrentTime(), target.getDuration()]);
      return [Number(cur), Number(dur)];
    } catch {
      return null;
    }
  }

  // `startSeconds` is fed from the same progress state we save periodically,
  // so it changes on every tick. `opts` must NOT be rebuilt on those
  // updates — react-youtube treats a new `opts` object as a real change
  // and reloads/reseeks the underlying iframe player, which pauses
  // playback. We only want the resume position once — at mount, or when
  // the video itself actually changes (e.g. Prev/Next) — so it's captured
  // into a ref synchronously during render (not an effect, which would run
  // one tick too late and hand the memo the previous video's position).
  const lastVideoIdRef = React.useRef<string | null | undefined>(undefined);
  const resumeSecondsRef = React.useRef(startSeconds);
  if (lastVideoIdRef.current !== youtubeVideoId) {
    lastVideoIdRef.current = youtubeVideoId;
    resumeSecondsRef.current = startSeconds;
  }

  const opts: YouTubeProps["opts"] = React.useMemo(() => ({
    width: "100%",
    height: "100%",
    playerVars: {
      start: Math.floor(resumeSecondsRef.current),
      rel: 0,
      modestbranding: 1,
      controls: 1,
      fs: 1,
      playsinline: 1,
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }), [youtubeVideoId]);

  function handleReady(e: { target: YouTubePlayer }) {
    playerRef.current = e.target;
    if (autoPlay) {
      try { e.target.playVideo(); } catch { /* Browser autoplay policy may block this. */ }
    }
  }

  function handleStateChange(e: { data: number; target: YouTubePlayer }) {
    const YT_PLAYING = 1;
    const YT_PAUSED = 2;
    const YT_ENDED = 0;

    clearPoll();

    if (e.data === YT_PLAYING) {
      // Periodic save while playing — every 60s, not every second, to
      // minimize Firestore writes (see README > Firestore optimization).
      intervalRef.current = setInterval(async () => {
        const result = await safeReadTime(e.target);
        if (result) onProgress(result[0], result[1]);
      }, 60000);
    }

    if (e.data === YT_PAUSED) {
      // Pausing is a natural checkpoint — force the save so the exact
      // position is captured even if you paused seconds after the last
      // throttled periodic save (otherwise a short viewing session could
      // end without ever persisting real progress).
      safeReadTime(e.target).then((result) => { if (result) onPause(result[0], result[1], true); });
    }

    if (e.data === YT_ENDED) {
      Promise.all([e.target.getCurrentTime(), e.target.getDuration()]).then(([cur, dur]) => {
        const currentSeconds = Number(cur);
        const durationSeconds = Number(dur);
        // Ignore an inconsistent early ended signal. It can happen when the
        // iframe reports a rounded duration near the end of a video.
        if (durationSeconds > 0 && currentSeconds < durationSeconds - 2) {
          onProgress(currentSeconds, durationSeconds, true);
          return;
        }
        onEnded(currentSeconds, durationSeconds);
      }).catch(() => {});
    }
  }

  // Save on page leave / unmount as a safety net.
  React.useEffect(() => {
    isMountedRef.current = true;
    function flushProgress() {
      const p = playerRef.current;
      if (!p) return;
      // Same reasoning as the pause handler — this is the last chance to
      // persist progress before the tab/route changes, so it must not be
      // silently dropped by the periodic-save throttle.
      safeReadTime(p).then((result) => { if (result) onProgress(result[0], result[1], true); });
    }
    window.addEventListener("beforeunload", flushProgress);
    window.addEventListener("pagehide", flushProgress);
    function handleVisibilityChange() {
      if (document.visibilityState === "hidden") flushProgress();
    }
    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => {
      window.removeEventListener("beforeunload", flushProgress);
      window.removeEventListener("pagehide", flushProgress);
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      clearPoll();
      flushProgress();
      // Set after the final save is *initiated* (safeReadTime still checks
      // isMountedRef itself before touching the player, but this ensures
      // any subsequent stray call — e.g. a late interval tick that slipped
      // through — is a guaranteed no-op).
      isMountedRef.current = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!youtubeVideoId) {
    if (detectVideoPlatform(videoUrl) === "facebook") {
      // Re-derive the canonical (Reel- or Watch-shaped) URL from whatever
      // videoUrl actually is, rather than assuming it's already in that
      // shape — defensive against any pre-fix record that slipped through
      // storage with a raw/unnormalized URL. generateCanonicalUrl() is
      // idempotent for an already-canonical URL, so this is a no-op for
      // every normal record.
      const href = generateCanonicalUrl(videoUrl) || videoUrl;
      return <FacebookEmbed key={href} href={href} videoUrl={videoUrl} className={className} />;
    }

    const embedUrl = generateEmbedUrl(videoUrl);

    if (embedUrl) {
      return (
        <div className={['relative z-0 w-full overflow-hidden rounded-xl bg-black shadow-sm', className].filter(Boolean).join(' ')}>
          {/* We do not know whether a generic iframe embed is portrait or
             landscape until the actual provider tells us. The safe default is
             to constrain width only and let the embedded player keep its own
             intrinsic height instead of forcing a landscape 16:9 box. */}
          <iframe
            src={embedUrl}
            className="block w-full border-0"
            allow="autoplay; encrypted-media; picture-in-picture; web-share"
            allowFullScreen
            title={videoUrl}
          />
        </div>
      );
    }

    return (
      <div className={['flex aspect-video w-full flex-col items-center justify-center gap-3 rounded-xl bg-secondary text-center', className].filter(Boolean).join(' ')}>
        <p className="text-sm text-muted-foreground">This video is hosted externally.</p>
        <a href={videoUrl} target="_blank" rel="noopener noreferrer" className="text-sm font-medium text-accent underline">
          Open video in a new tab →
        </a>
      </div>
    );
  }

  return (
    <div className={['relative z-0 aspect-video w-full overflow-hidden rounded-xl bg-black shadow-sm', className].filter(Boolean).join(' ')}>
      <YouTube
        videoId={youtubeVideoId}
        opts={opts}
        onReady={handleReady}
        onStateChange={handleStateChange}
        className="h-full w-full"
        iframeClassName="h-full w-full"
      />
    </div>
  );
}
