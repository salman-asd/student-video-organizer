import assert from "node:assert/strict";
import { describe, it } from "node:test";

import { parseQuizQuestionsFromText } from "./aiService";

describe("parseQuizQuestionsFromText", () => {
  it("parses a valid JSON quiz response with the expected shape", () => {
    const result = parseQuizQuestionsFromText([
      "```json",
      "[",
      "  {",
      "    \"id\": \"q1\",",
      "    \"prompt\": \"What is the main idea?\",",
      "    \"options\": [{ \"id\": \"a\", \"text\": \"Alpha\" }, { \"id\": \"b\", \"text\": \"Beta\" }],",
      "    \"correctOptionId\": \"a\",",
      "    \"explanation\": \"Alpha is correct because it matches the transcript.\"",
      "  }",
      "]",
      "```",
    ].join("\n"));

    assert.deepEqual(result, [{
      id: "q1",
      prompt: "What is the main idea?",
      options: [{ id: "a", text: "Alpha" }, { id: "b", text: "Beta" }],
      correctOptionId: "a",
      explanation: "Alpha is correct because it matches the transcript.",
    }]);
  });

  it("rejects malformed JSON or missing required fields", () => {
    assert.throws(() => parseQuizQuestionsFromText("not-json"), /Invalid quiz response/);
    assert.throws(() => parseQuizQuestionsFromText(JSON.stringify([{ prompt: "oops" }])), /Invalid quiz response/);
  });
});
