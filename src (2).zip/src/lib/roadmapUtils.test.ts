import assert from "node:assert/strict";
import { describe, it } from "node:test";

import { sanitizeRoadmapSteps } from "./roadmapUtils";

describe("sanitizeRoadmapSteps", () => {
  it("keeps valid roadmap steps and ignores blank or malformed entries", () => {
    const result = sanitizeRoadmapSteps([
      { title: "Learn the basics", description: "Start with fundamentals.", order: 1 },
      { title: "", description: "Missing title.", order: 2 },
      { title: "Practice", description: "Apply it.", order: 0 },
      { title: "Wrap up", description: "Review progress.", order: 3 },
      null,
    ]);

    assert.deepEqual(result, [
      { title: "Practice", description: "Apply it.", order: 0 },
      { title: "Learn the basics", description: "Start with fundamentals.", order: 1 },
      { title: "Wrap up", description: "Review progress.", order: 3 },
    ]);
  });

  it("fills missing descriptions and reorders by the provided step order", () => {
    const result = sanitizeRoadmapSteps([
      { title: "Final review", description: "", order: 5 },
      { title: "Practice", order: 2 },
      { title: "Foundation", description: "Build confidence.", order: 1 },
    ]);

    assert.deepEqual(result, [
      { title: "Foundation", description: "Build confidence.", order: 1 },
      { title: "Practice", description: "", order: 2 },
      { title: "Final review", description: "", order: 5 },
    ]);
  });
});
