import assert from "node:assert/strict";
import { describe, it } from "node:test";

import { toSummaryHtml } from "./summaryHtml";

describe("toSummaryHtml", () => {
  it("wraps plain text as paragraphs without breaking existing HTML", () => {
    assert.equal(toSummaryHtml("First line\n\nSecond line"), "<p>First line</p><p>Second line</p>");
    assert.equal(toSummaryHtml("<h2>Heading</h2><p>Body</p>"), "<h2>Heading</h2><p>Body</p>");
  });

  it("treats empty content as empty HTML", () => {
    assert.equal(toSummaryHtml("   \n\n  "), "");
  });
});
