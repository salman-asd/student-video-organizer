import type { RoadmapStep } from "@/types";

export function sanitizeRoadmapSteps(input: Array<Partial<RoadmapStep> | null | undefined>): RoadmapStep[] {
  const cleaned = (input ?? [])
    .filter((step): step is Partial<RoadmapStep> => !!step)
    .map((step) => ({
      title: String(step.title ?? "").trim(),
      description: String(step.description ?? "").trim(),
      order: Number.isFinite(step.order) ? Number(step.order) : 0,
    }))
    .filter((step) => !!step.title && step.title.length > 0)
    .sort((a, b) => {
      const orderDelta = (a.order ?? 0) - (b.order ?? 0);
      if (orderDelta !== 0) return orderDelta;
      return a.title.localeCompare(b.title);
    })
    .map((step, index) => ({
      ...step,
      order: typeof step.order === "number" && Number.isFinite(step.order) ? step.order : index,
      description: step.description || "",
    }));

  return cleaned;
}
